import whisper
import sounddevice as sd
import numpy as np
import librosa
import time
from typing import Optional
import io
import wave

cached_model = None

class SpeechRecognition:
    @staticmethod
    def get_whisper_model(model_name: str = "base"):
        global cached_model
        if cached_model is None:
            print(f"Loading Whisper {model_name} model...")
            cached_model = whisper.load_model(model_name)
        return cached_model

    @staticmethod
    def record_audio(duration: int = 5, sample_rate: int = 16000) -> np.ndarray:
        print("Available audio devices:")
        print(sd.query_devices())  # List available devices for debugging

        # Use the default device (index 0)
        device_index = 0  # Update this to a valid device index
        print(f"Using audio device {device_index}...")
        
        audio = sd.rec(
            int(duration * sample_rate),
            samplerate=sample_rate,
            channels=1,
            dtype='float32',
            device=device_index  # Specify the device explicitly
        )
        sd.wait()
        print("Recording finished.")

        # Flatten the audio array
        audio = audio.flatten()

        # Check for empty or invalid audio
        if np.all(audio == 0):
            raise ValueError("Recorded audio is empty or silent.")
        if np.any(np.isnan(audio)):
            raise ValueError("Recorded audio contains NaN values.")
        return audio

    @staticmethod
    def preprocess_audio(audio: np.ndarray, sample_rate: int = 16000) -> np.ndarray:
        # Trim silence from the audio
        trimmed_audio, _ = librosa.effects.trim(audio, top_db=20)

        # Normalize the audio
        if np.max(np.abs(trimmed_audio)) == 0:
            raise ValueError("Audio normalization failed: maximum amplitude is zero.")
        normalized_audio = trimmed_audio / np.max(np.abs(trimmed_audio))

        # Check for NaN values
        if np.any(np.isnan(normalized_audio)):
            raise ValueError("Preprocessed audio contains NaN values.")
        return normalized_audio

    @staticmethod
    def audio_to_bytes(audio: np.ndarray, sample_rate: int = 16000) -> bytes:
        scaled_audio = np.int16(audio * 32767)
        buffer = io.BytesIO()
        with wave.open(buffer, 'wb') as wav_file:
            wav_file.setnchannels(1)
            wav_file.setsampwidth(2)  # 16-bit
            wav_file.setframerate(sample_rate)
            wav_file.writeframes(scaled_audio.tobytes())
        return buffer.getvalue()

    @staticmethod
    def transcribe_audio(audio_data: np.ndarray, sample_rate: int = 16000) -> str:
        model = SpeechRecognition.get_whisper_model("base")
        print("Transcribing with Whisper...")
        start_time = time.time()

        try:
            result = model.transcribe(audio_data, fp16=False)
        except Exception as e:
            raise RuntimeError(f"Whisper transcription failed: {e}")

        end_time = time.time()
        print(f"Transcription Time: {end_time - start_time:.2f} seconds")

        # Log the transcription result for debugging
        print(f"Transcription Result: {result}")

        # Validate the output
        if "text" not in result or not isinstance(result["text"], str):
            raise ValueError("Whisper model produced invalid output.")
        return result["text"]

    @staticmethod
    def process_and_transcribe(duration: Optional[int] = 3, sample_rate: Optional[int] = 16000) -> dict:
        try:
            audio = SpeechRecognition.record_audio(duration, sample_rate)
            processed_audio = SpeechRecognition.preprocess_audio(audio, sample_rate)
            transcription = SpeechRecognition.transcribe_audio(processed_audio, sample_rate)

            return {
                "transcription": transcription,
                "duration": duration,
                "sample_rate": sample_rate,
                "status": "success"
            }
        except Exception as e:
            raise RuntimeError(f"An error occurred during processing: {e}")