from fastapi import FastAPI, HTTPException
from utils.speech_to_text import SpeechRecognition
from typing import Optional

app = FastAPI(title="Real-time Speech to Text API")

@app.get("/")
async def root():
    return {"message": "Welcome to Real-time Speech to Text API"}

@app.post("/transcribe/")
async def transcribe_audio(
    duration: Optional[int] = 3,  
    sample_rate: Optional[int] = 16000
):
    try:
        result = SpeechRecognition.process_and_transcribe(duration, sample_rate)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An error occurred: {str(e)}")

@app.get("/health")
async def health_check():
    return {"status": "healthy"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)